class AnimeFLVParseError(Exception):
    pass
